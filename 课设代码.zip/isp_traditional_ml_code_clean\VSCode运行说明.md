# VS Code 运行说明

## 1. 打开代码文件夹

在 VS Code 中打开：

```text
code/isp_traditional_ml
```

## 2. 安装依赖

在 VS Code 终端运行：

```powershell
pip install -r requirements.txt
```

## 3. 运行演示脚本

在 VS Code 终端运行：

```powershell
python run_demo.py
```

运行后会在项目目录生成：

```text
work/vscode_demo_output
```

该目录中包含 5 张 640×512 的 PNG 灰度超分辨率结果图。

## 4. 完整生成比赛结果

如需重新生成完整结果，运行：

```powershell
python run_all.py --dataset_root "..\..\data\isp_dataset\超分竞赛数据集" --output_root "..\..\work\vscode_full_output"
```

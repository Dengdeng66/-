import argparse
import math
from pathlib import Path

import numpy as np
from PIL import Image


def psnr(pred_path: Path, gt_path: Path) -> float:
    pred = np.asarray(Image.open(pred_path).convert("L"), dtype=np.float32)
    gt = np.asarray(Image.open(gt_path).convert("L"), dtype=np.float32)
    mse = float(np.mean((pred - gt) ** 2))
    if mse == 0:
        return 99.0
    return 20.0 * math.log10(255.0 / math.sqrt(mse))


def main() -> None:
    parser = argparse.ArgumentParser(description="Calculate PSNR for super-resolution results.")
    parser.add_argument("--pred_dir", required=True, help="Prediction image directory.")
    parser.add_argument("--gt_dir", required=True, help="Ground truth image directory.")
    args = parser.parse_args()

    pred_dir = Path(args.pred_dir)
    gt_dir = Path(args.gt_dir)
    scores = []

    for pred_path in sorted(pred_dir.glob("*.png")):
        gt_path = gt_dir / pred_path.name
        if gt_path.exists():
            scores.append(psnr(pred_path, gt_path))

    if not scores:
        raise RuntimeError("No matched prediction/GT image pairs found.")

    print(f"count: {len(scores)}")
    print(f"mean_psnr: {np.mean(scores):.4f}")
    print(f"min_psnr: {np.min(scores):.4f}")
    print(f"max_psnr: {np.max(scores):.4f}")


if __name__ == "__main__":
    main()

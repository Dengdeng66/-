import argparse
from pathlib import Path

from PIL import Image

from src.model import TraditionalSuperResolution


def main():
    parser = argparse.ArgumentParser(description="Run a small ISP super-resolution demo.")
    parser.add_argument("--input_dir", default=None, help="Demo input directory. Default uses project dataset.")
    parser.add_argument("--output_dir", default=None, help="Demo output directory.")
    args = parser.parse_args()

    project_root = Path(__file__).resolve().parents[2]
    if args.input_dir:
        input_dir = Path(args.input_dir)
    else:
        input_dir = project_root / "data" / "isp_dataset" / "超分竞赛数据集" / "初赛测试集" / "input_320"

    output_dir = Path(args.output_dir) if args.output_dir else project_root / "work" / "vscode_demo_output"
    output_dir.mkdir(parents=True, exist_ok=True)

    model = TraditionalSuperResolution(target_size=(640, 512), sharpen=True)
    image_paths = sorted(input_dir.glob("*.png"))[:5]

    print("ISP traditional super-resolution baseline")
    print("=" * 48)
    print(f"Input dir: {input_dir}")
    print(f"Output dir: {output_dir}")
    print(f"Demo image count: {len(image_paths)}")
    print("Method: Bicubic interpolation + Unsharp Mask")
    print("Deep learning used: No")
    print("-" * 48)

    for image_path in image_paths:
        output_path = output_dir / image_path.name
        model.predict_file(image_path, output_path)
        image = Image.open(output_path)
        print(f"{image_path.name} -> {output_path.name}, size={image.size}, mode={image.mode}")

    print("-" * 48)
    print("Done: generated 640x512 PNG grayscale images.")


if __name__ == "__main__":
    main()

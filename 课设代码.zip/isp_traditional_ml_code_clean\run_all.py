import argparse
from pathlib import Path

from src.model import TraditionalSuperResolution


def infer_folder(model: TraditionalSuperResolution, input_dir: Path, output_dir: Path) -> int:
    image_paths = sorted(input_dir.glob("*.png"))
    if not image_paths:
        raise FileNotFoundError(f"No PNG images found in {input_dir}")

    output_dir.mkdir(parents=True, exist_ok=True)
    for image_path in image_paths:
        model.predict_file(image_path, output_dir / image_path.name)
    return len(image_paths)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate ISP competition result folders.")
    parser.add_argument("--dataset_root", required=True, help="Path to 超分竞赛数据集 directory.")
    parser.add_argument("--output_root", default="result", help="Output directory.")
    args = parser.parse_args()

    dataset_root = Path(args.dataset_root)
    output_root = Path(args.output_root)
    model = TraditionalSuperResolution(target_size=(640, 512), sharpen=True)

    tasks = [
        ("preliminary", dataset_root / "初赛测试集" / "input_320"),
        ("final_validation", dataset_root / "决赛测试集" / "test_finalRound" / "input_160"),
        ("final_test", dataset_root / "决赛测试集" / "无监督"),
    ]

    for output_name, input_dir in tasks:
        count = infer_folder(model, input_dir, output_root / output_name)
        print(f"{output_name}: generated {count} images")


if __name__ == "__main__":
    main()

from pathlib import Path

from PIL import Image, ImageFilter


class TraditionalSuperResolution:
    """Traditional non-deep-learning super-resolution baseline."""

    def __init__(self, target_size=(640, 512), sharpen=True):
        self.target_size = target_size
        self.sharpen = sharpen

    def predict(self, image: Image.Image) -> Image.Image:
        image = image.convert("L")
        image = image.resize(self.target_size, Image.Resampling.BICUBIC)
        if self.sharpen:
            image = image.filter(ImageFilter.UnsharpMask(radius=1.0, percent=80, threshold=2))
        return image

    def predict_file(self, input_path, output_path):
        input_path = Path(input_path)
        output_path = Path(output_path)
        image = Image.open(input_path)
        result = self.predict(image)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        result.save(output_path)

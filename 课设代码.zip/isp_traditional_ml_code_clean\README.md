# ISP 图像超分辨率传统机器学习课设代码

## 1. 项目说明

本项目用于完成 ISP 图像超分辨率竞赛任务。程序不使用 CNN、RNN、Transformer、U-Net 等深度学习模型，而是采用传统图像处理方法：

```text
灰度图读取 -> Bicubic 插值放大到 640x512 -> Unsharp Mask 锐化 -> 输出 PNG 灰度图
```

该方案适合作为机器学习课程设计中的传统方法基线，重点体现数据读取、模型推理、结果生成、指标计算和提交文件组织流程。

## 2. 目录结构

```text
isp_traditional_ml/
├── README.md
├── requirements.txt
├── run_all.py
├── evaluate_psnr.py
└── src/
    ├── infer.py
    └── model.py
```

## 3. 安装依赖

```bash
pip install -r requirements.txt
```

## 4. 单目录推理

```bash
python src/infer.py --input_dir <输入图像目录> --output_dir <输出结果目录>
```

示例：

```bash
python src/infer.py --input_dir data/input_320 --output_dir outputs/preliminary
```

## 5. 一键生成比赛结果

如果数据集目录为：

```text
超分竞赛数据集/
├── 初赛测试集/input_320
├── 决赛测试集/test_finalRound/input_160
└── 决赛测试集/无监督
```

运行：

```bash
python run_all.py --dataset_root <超分竞赛数据集目录> --output_root <输出目录>
```

程序会生成：

```text
输出目录/
├── preliminary
├── final_validation
└── final_test
```

## 6. 本地 PSNR 评价

如果有 GT 目录，可以运行：

```bash
python evaluate_psnr.py --pred_dir <预测结果目录> --gt_dir <GT目录>
```

## 7. 说明

本代码输出图像均为 PNG 灰度图，分辨率为 640x512，文件名与输入图像保持一致。

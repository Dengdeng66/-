import argparse
from pathlib import Path

from model import TraditionalSuperResolution


def run(input_dir: Path, output_dir: Path) -> None:
    model = TraditionalSuperResolution(target_size=(640, 512), sharpen=True)
    image_paths = sorted(input_dir.glob("*.png"))

    if not image_paths:
        raise FileNotFoundError(f"No PNG images found in {input_dir}")

    output_dir.mkdir(parents=True, exist_ok=True)
    for image_path in image_paths:
        model.predict_file(image_path, output_dir / image_path.name)


def main() -> None:
    parser = argparse.ArgumentParser(description="Traditional ISP super-resolution inference.")
    parser.add_argument("--input_dir", required=True, help="Directory containing low-resolution PNG images.")
    parser.add_argument("--output_dir", required=True, help="Directory for 640x512 output PNG images.")
    parser.add_argument("--weights", default=None, help="Unused. Kept for competition interface compatibility.")
    args = parser.parse_args()

    run(Path(args.input_dir), Path(args.output_dir))


if __name__ == "__main__":
    main()

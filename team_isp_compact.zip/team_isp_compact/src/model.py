# Parameter-free nearest-neighbor baseline.

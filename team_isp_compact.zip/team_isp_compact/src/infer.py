import argparse
from pathlib import Path
from PIL import Image


def infer(input_dir, output_dir):
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for path in sorted(input_dir.glob("*.png")):
        image = Image.open(path).convert("L")
        image = image.resize((640, 512), Image.Resampling.NEAREST)
        image.save(output_dir / path.name, format="PNG", optimize=True, compress_level=9)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_dir", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--weights", default=None)
    args = parser.parse_args()
    infer(args.input_dir, args.output_dir)


if __name__ == "__main__":
    main()

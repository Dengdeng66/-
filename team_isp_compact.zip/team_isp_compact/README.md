# ISP compact traditional baseline

This submission uses a non-deep-learning baseline:
grayscale image reading + nearest-neighbor resizing to 640x512.

All output images are PNG grayscale images and keep the same filenames as inputs.
